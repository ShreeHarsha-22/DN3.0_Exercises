package main.java.com.harsha.EmployeeManagementSystem.projection;

public interface EmployeeProjection {
    Long getId();

    String getName();

    String getEmail();
}
